import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def props = message.getProperties()
    int start = (props['vm.startIndex'] ?: '1') as int
    int max   = (props['vm.maxIndex']   ?: '50') as int
    
    def sb = new StringBuilder('<IdxList>')
    for (int i = start; i <= max; i++) {
        sb.append('<Idx>').append(i).append('</Idx>')
    }
    sb.append('</IdxList>')
    
    message.setBody(sb.toString())
    return message
}
