import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.mapping.ValueMappingApi

// Inject ValueMappingApi service
def ValueMappingApi vmApi

def Message processData(Message message) {

    def props = message.getProperties()
    def body  = message.getBody(String)

    // Extract current index
    def curIdx = body.replaceAll("<[/]?Idx>", "").trim()
    message.setProperty("vm.curIndex", curIdx)

    def srcAgency = props['vm.sourceAgency']
    def tgtAgency = props['vm.targetAgency']

    // Perform Value Mapping Lookup
    def iflowId = vmApi.getMappedValue(srcAgency, curIdx, tgtAgency, "VM_UNDEPLOY")

    // Save result as property
    message.setProperty("iflowId", iflowId ?: "")

    // Debug log
    def logMsg = "Index: ${curIdx}, iFlowId: ${iflowId}"
    messageLogFactory.getMessageLog(message).addAttachmentAsString("VM Lookup Result", logMsg, "text/plain")

    return message
}
