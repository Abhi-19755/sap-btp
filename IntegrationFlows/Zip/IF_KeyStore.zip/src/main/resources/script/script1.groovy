import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

def Message processData(Message message) {

    // Get the body (XML) as a string
    def body = message.getBody(String)
    
    // Parse the XML
    def xml = new XmlSlurper().parseText(body)
    
    // Get the 'ValidNotAfter' value
    def validNotAfterStr = xml.KeystoreEntry.ValidNotAfter.text()
    
    // Define date format
    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")
    sdf.setTimeZone(TimeZone.getTimeZone("UTC"))

    // Parse ValidNotAfter date and get current date
    def validNotAfterDate = sdf.parse(validNotAfterStr)
    def currentDate = new Date()
    
    // Calculate difference in milliseconds
    def diffInMs = validNotAfterDate.time - currentDate.time
    def diffInDays = diffInMs / (1000 * 60 * 60 * 24)

    // Set header based on expiry condition
    if (diffInDays <= 70 && diffInDays >= 0) {
        message.setHeader("CertificateExpiring", true)
    }
    else if (diffInDays < 0) {
        message.setHeader("CertificateExpiring", "expired")
    }
    else {
        message.setHeader("CertificateExpiring", false)
    }

    return message
}
